"""
synthetic_data_generator.py
Generates a labelled dataset of emergency triage records as would be
collected by a junior EMT inside an ambulance.
"""

import numpy as np
import pandas as pd
from typing import Tuple

np.random.seed(42)

N = 20_000  # total records; tweak as needed

# ── Emergency type proportions (roughly realistic) ──────────────────────────
EMERGENCY_TYPES = [
    "cardiac", "trauma", "respiratory", "stroke_neuro",
    "sepsis", "poisoning_overdose", "obstetric", "diabetic"
]
WEIGHTS = [0.20, 0.18, 0.15, 0.14, 0.12, 0.09, 0.07, 0.05]


def clamp(x, lo, hi):
    return np.clip(x, lo, hi)


def sample_cardiac(n):
    """MI / arrest. HR irregular, BP low or high, chest pain."""
    # pick element-wise from three arrays
    hr_choices = np.stack([
        np.random.normal(42, 8, n),
        np.random.normal(115, 20, n),
        np.random.normal(78, 15, n)
    ], axis=1)
    choice_idx = np.random.choice([0, 1, 2], size=n, p=[0.15, 0.45, 0.40])
    hr = hr_choices[np.arange(n), choice_idx]

    bp_sys = np.where(choice_idx == 0,
                      np.random.normal(68, 12, n),
                      np.random.normal(155, 25, n))
    bp_dia = (bp_sys * np.random.uniform(0.55, 0.68, n))
    spo2   = clamp(np.random.normal(91, 6, n), 60, 100)
    rr     = clamp(np.random.normal(22, 6, n), 6, 45)
    gcs    = np.where(choice_idx == 0,
                      np.random.choice([3, 4, 5], n),
                      np.random.randint(12, 16, n))
    temp   = np.random.normal(36.8, 0.5, n)
    glucose= np.random.normal(140, 40, n)
    pupils_unequal = np.random.choice([0, 1], n, p=[0.9, 0.1])
    chest_pain     = np.random.choice([0, 1], n, p=[0.05, 0.95])
    sweating       = np.random.choice([0, 1], n, p=[0.15, 0.85])
    collapse       = (choice_idx == 0).astype(int)
    road_accident  = np.zeros(n, int)
    bleeding       = np.zeros(n, int)
    breathlessness = np.random.choice([0, 1], n, p=[0.40, 0.60])
    wheezing       = np.zeros(n, int)
    confusion      = np.random.choice([0, 1], n, p=[0.70, 0.30])
    drug_intake    = np.zeros(n, int)
    pregnancy      = np.zeros(n, int)
    known_diabetes = np.zeros(n, int)
    ecg_abnormal   = np.random.choice([0, 1], n, p=[0.10, 0.90])
    return locals()


def sample_trauma(n):
    hr     = clamp(np.random.normal(118, 22, n), 40, 180)
    bp_sys = clamp(np.random.normal(88, 22, n), 40, 180)
    bp_dia = (bp_sys * np.random.uniform(0.55, 0.68, n))
    spo2   = clamp(np.random.normal(94, 5, n), 60, 100)
    rr     = clamp(np.random.normal(24, 6, n), 6, 45)
    gcs    = clamp(np.random.normal(10, 4, n), 3, 15).astype(int)
    temp   = np.random.normal(36.5, 0.8, n)
    glucose= np.random.normal(120, 30, n)
    pupils_unequal = np.where(gcs < 9,
                              np.random.choice([0, 1], n, p=[0.4, 0.6]),
                              np.zeros(n, int))
    chest_pain  = np.random.choice([0, 1], n, p=[0.60, 0.40])
    sweating    = np.random.choice([0, 1], n, p=[0.30, 0.70])
    collapse    = np.random.choice([0, 1], n, p=[0.40, 0.60])
    road_accident = np.random.choice([0, 1], n, p=[0.10, 0.90])
    bleeding    = np.random.choice([0, 1], n, p=[0.15, 0.85])
    breathlessness = np.random.choice([0, 1], n, p=[0.50, 0.50])
    wheezing    = np.zeros(n, int)
    confusion   = np.where(gcs < 10, np.ones(n, int), np.zeros(n, int))
    drug_intake = np.zeros(n, int)
    pregnancy   = np.zeros(n, int)
    known_diabetes = np.zeros(n, int)
    ecg_abnormal = np.random.choice([0, 1], n, p=[0.80, 0.20])
    return locals()


def sample_respiratory(n):
    hr     = clamp(np.random.normal(108, 18, n), 40, 180)
    bp_sys = clamp(np.random.normal(130, 20, n), 60, 210)
    bp_dia = (bp_sys * np.random.uniform(0.55, 0.68, n))
    spo2   = clamp(np.random.normal(83, 7, n), 55, 100)  # critically low
    rr     = clamp(np.random.normal(30, 8, n), 6, 55)
    gcs    = clamp(np.random.normal(13, 2, n), 3, 15).astype(int)
    temp   = np.random.normal(37.2, 0.8, n)
    glucose= np.random.normal(110, 25, n)
    pupils_unequal = np.zeros(n, int)
    chest_pain  = np.random.choice([0, 1], n, p=[0.50, 0.50])
    sweating    = np.random.choice([0, 1], n, p=[0.40, 0.60])
    collapse    = np.random.choice([0, 1], n, p=[0.70, 0.30])
    road_accident = np.zeros(n, int)
    bleeding    = np.zeros(n, int)
    breathlessness = np.ones(n, int)
    wheezing    = np.random.choice([0, 1], n, p=[0.25, 0.75])
    confusion   = np.random.choice([0, 1], n, p=[0.60, 0.40])
    drug_intake = np.zeros(n, int)
    pregnancy   = np.zeros(n, int)
    known_diabetes = np.zeros(n, int)
    ecg_abnormal = np.random.choice([0, 1], n, p=[0.70, 0.30])
    return locals()


def sample_stroke_neuro(n):
    hr     = clamp(np.random.normal(88, 18, n), 40, 160)
    bp_sys = clamp(np.random.normal(175, 30, n), 80, 260)  # hypertensive
    bp_dia = (bp_sys * np.random.uniform(0.55, 0.68, n))
    spo2   = clamp(np.random.normal(94, 5, n), 70, 100)
    rr     = clamp(np.random.normal(18, 5, n), 6, 40)
    gcs    = clamp(np.random.normal(9, 4, n), 3, 15).astype(int)
    temp   = np.random.normal(37.0, 0.7, n)
    glucose= np.random.normal(130, 35, n)
    pupils_unequal = np.where(gcs < 10,
                              np.random.choice([0, 1], n, p=[0.20, 0.80]),
                              np.random.choice([0, 1], n, p=[0.70, 0.30]))
    chest_pain  = np.zeros(n, int)
    sweating    = np.random.choice([0, 1], n, p=[0.60, 0.40])
    collapse    = np.random.choice([0, 1], n, p=[0.30, 0.70])
    road_accident = np.zeros(n, int)
    bleeding    = np.zeros(n, int)
    breathlessness = np.random.choice([0, 1], n, p=[0.60, 0.40])
    wheezing    = np.zeros(n, int)
    confusion   = np.random.choice([0, 1], n, p=[0.20, 0.80])
    drug_intake = np.zeros(n, int)
    pregnancy   = np.zeros(n, int)
    known_diabetes = np.zeros(n, int)
    ecg_abnormal = np.random.choice([0, 1], n, p=[0.60, 0.40])
    return locals()


def sample_sepsis(n):
    # SIRS criteria-inspired: high/low temp, high HR, low BP, high RR
    temp_low  = np.random.normal(35.2, 0.6, n)
    temp_high = np.random.normal(39.5, 0.8, n)
    temp_mask = np.random.choice([0, 1], n, p=[0.30, 0.70])
    temp = np.where(temp_mask == 1, temp_high, temp_low)

    hr     = clamp(np.random.normal(118, 22, n), 40, 200)
    bp_sys = clamp(np.random.normal(82, 18, n), 40, 160)
    bp_dia = (bp_sys * np.random.uniform(0.55, 0.68, n))
    spo2   = clamp(np.random.normal(91, 7, n), 60, 100)
    rr     = clamp(np.random.normal(26, 6, n), 6, 50)
    gcs    = clamp(np.random.normal(11, 3, n), 3, 15).astype(int)
    glucose= clamp(np.random.normal(155, 50, n), 40, 400)
    pupils_unequal = np.zeros(n, int)
    chest_pain  = np.zeros(n, int)
    sweating    = np.random.choice([0, 1], n, p=[0.30, 0.70])
    collapse    = np.random.choice([0, 1], n, p=[0.50, 0.50])
    road_accident = np.zeros(n, int)
    bleeding    = np.zeros(n, int)
    breathlessness = np.random.choice([0, 1], n, p=[0.40, 0.60])
    wheezing    = np.zeros(n, int)
    confusion   = np.random.choice([0, 1], n, p=[0.30, 0.70])
    drug_intake = np.zeros(n, int)
    pregnancy   = np.zeros(n, int)
    known_diabetes = np.random.choice([0, 1], n, p=[0.50, 0.50])
    ecg_abnormal = np.random.choice([0, 1], n, p=[0.70, 0.30])
    return locals()


def sample_poisoning(n):
    hr     = clamp(np.random.normal(58, 25, n), 20, 160)
    bp_sys = clamp(np.random.normal(90, 20, n), 40, 170)
    bp_dia = (bp_sys * np.random.uniform(0.55, 0.68, n))
    spo2   = clamp(np.random.normal(87, 9, n), 55, 100)
    rr     = clamp(np.random.normal(10, 5, n), 2, 35)   # depressed breathing
    gcs    = clamp(np.random.normal(7, 4, n), 3, 15).astype(int)
    temp   = np.random.normal(36.3, 1.0, n)
    glucose= np.random.normal(105, 30, n)
    pupils_unequal = np.random.choice([0, 1], n, p=[0.50, 0.50])
    chest_pain  = np.zeros(n, int)
    sweating    = np.random.choice([0, 1], n, p=[0.40, 0.60])
    collapse    = np.random.choice([0, 1], n, p=[0.20, 0.80])
    road_accident = np.zeros(n, int)
    bleeding    = np.zeros(n, int)
    breathlessness = np.random.choice([0, 1], n, p=[0.30, 0.70])
    wheezing    = np.zeros(n, int)
    confusion   = np.random.choice([0, 1], n, p=[0.10, 0.90])
    drug_intake = np.ones(n, int)
    pregnancy   = np.zeros(n, int)
    known_diabetes = np.zeros(n, int)
    ecg_abnormal = np.random.choice([0, 1], n, p=[0.60, 0.40])
    return locals()


def sample_obstetric(n):
    hr     = clamp(np.random.normal(112, 20, n), 60, 180)
    bp_sys = clamp(np.random.normal(95, 22, n), 50, 180)
    bp_dia = (bp_sys * np.random.uniform(0.55, 0.68, n))
    spo2   = clamp(np.random.normal(96, 4, n), 78, 100)
    rr     = clamp(np.random.normal(22, 5, n), 10, 40)
    gcs    = clamp(np.random.normal(13, 2, n), 3, 15).astype(int)
    temp   = np.random.normal(37.1, 0.7, n)
    glucose= np.random.normal(115, 25, n)
    pupils_unequal = np.zeros(n, int)
    chest_pain  = np.zeros(n, int)
    sweating    = np.random.choice([0, 1], n, p=[0.40, 0.60])
    collapse    = np.random.choice([0, 1], n, p=[0.40, 0.60])
    road_accident = np.zeros(n, int)
    bleeding    = np.random.choice([0, 1], n, p=[0.05, 0.95])
    breathlessness = np.random.choice([0, 1], n, p=[0.60, 0.40])
    wheezing    = np.zeros(n, int)
    confusion   = np.random.choice([0, 1], n, p=[0.70, 0.30])
    drug_intake = np.zeros(n, int)
    pregnancy   = np.ones(n, int)
    known_diabetes = np.random.choice([0, 1], n, p=[0.80, 0.20])
    ecg_abnormal = np.random.choice([0, 1], n, p=[0.80, 0.20])
    return locals()


def sample_diabetic(n):
    glucose_low  = clamp(np.random.normal(38, 10, n), 10, 70)   # hypo
    glucose_high = clamp(np.random.normal(420, 80, n), 250, 700) # hyper
    glucose_mask = np.random.choice([0, 1], n, p=[0.45, 0.55])
    glucose = np.where(glucose_mask == 1, glucose_high, glucose_low)

    hr     = clamp(np.random.normal(105, 20, n), 40, 170)
    bp_sys = clamp(np.random.normal(105, 25, n), 50, 200)
    bp_dia = (bp_sys * np.random.uniform(0.55, 0.68, n))
    spo2   = clamp(np.random.normal(95, 4, n), 75, 100)
    rr     = clamp(np.random.normal(20, 6, n), 6, 42)
    gcs    = clamp(np.random.normal(10, 4, n), 3, 15).astype(int)
    temp   = np.random.normal(36.9, 0.7, n)
    pupils_unequal = np.zeros(n, int)
    chest_pain  = np.random.choice([0, 1], n, p=[0.70, 0.30])
    sweating    = np.where(glucose_mask == 0,
                           np.ones(n, int),   # hypo → sweating
                           np.random.choice([0, 1], n, p=[0.60, 0.40]))
    collapse    = np.random.choice([0, 1], n, p=[0.40, 0.60])
    road_accident = np.zeros(n, int)
    bleeding    = np.zeros(n, int)
    breathlessness = np.random.choice([0, 1], n, p=[0.60, 0.40])
    wheezing    = np.zeros(n, int)
    confusion   = np.where(gcs < 10, np.ones(n, int),
                           np.random.choice([0, 1], n, p=[0.50, 0.50]))
    drug_intake = np.zeros(n, int)
    pregnancy   = np.zeros(n, int)
    known_diabetes = np.ones(n, int)
    ecg_abnormal = np.random.choice([0, 1], n, p=[0.60, 0.40])
    return locals()


SAMPLERS = {
    "cardiac":            sample_cardiac,
    "trauma":             sample_trauma,
    "respiratory":        sample_respiratory,
    "stroke_neuro":       sample_stroke_neuro,
    "sepsis":             sample_sepsis,
    "poisoning_overdose": sample_poisoning,
    "obstetric":          sample_obstetric,
    "diabetic":           sample_diabetic,
}

VITAL_COLS = [
    "hr", "bp_sys", "bp_dia", "spo2", "rr",
    "gcs", "temp", "glucose",
]
SYMPTOM_COLS = [
    "pupils_unequal", "chest_pain", "sweating", "collapse",
    "road_accident", "bleeding", "breathlessness", "wheezing",
    "confusion", "drug_intake", "pregnancy", "known_diabetes",
    "ecg_abnormal",
]
EXCLUDE = {"n", "locals"}  # names not to pull from locals()


def build_records(n_total: int) -> pd.DataFrame:
    counts = (np.array(WEIGHTS) * n_total).astype(int)
    counts[-1] += n_total - counts.sum()  # absorb rounding remainder

    frames = []
    cols_to_keep = set(VITAL_COLS + SYMPTOM_COLS)
    for etype, count in zip(EMERGENCY_TYPES, counts):
        raw = SAMPLERS[etype](count)
        keep = {k: v for k, v in raw.items() if k in cols_to_keep}
        df = pd.DataFrame(keep)
        df["emergency_type"] = etype
        frames.append(df)

    df = pd.concat(frames, ignore_index=True)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)

    # numeric rounding
    for c in ["hr", "bp_sys", "bp_dia", "rr", "glucose"]:
        df[c] = df[c].round(1)
    for c in ["spo2", "temp"]:
        df[c] = df[c].round(1)

    return df


def assign_care_needs(df: pd.DataFrame) -> pd.DataFrame:
    """
    Rule-based multi-label care need assignment.
    These rules encode the 'Critical Patterns' from the problem specification.
    """
    d = df.copy()

    # Shock index proxy: HR / SBP > 1.0 → haemodynamic instability
    d["shock_index"] = d["hr"] / d["bp_sys"].clip(lower=1)

    d["need_icu"]          = 0
    d["need_ventilator"]   = 0
    d["need_ot"]           = 0
    d["need_cardiologist"] = 0
    d["need_neurosurgeon"] = 0
    d["need_blood_bank"]   = 0
    d["need_cath_lab"]     = 0
    d["need_toxicology"]   = 0
    d["need_obstetrician"] = 0
    d["need_ct_scan"]      = 0

    # ── Cardiac ──────────────────────────────────────────────────────────────
    cardiac = d["emergency_type"] == "cardiac"
    d.loc[cardiac, "need_icu"]          = 1
    d.loc[cardiac, "need_cardiologist"] = 1
    d.loc[cardiac, "need_cath_lab"]     = 1
    d.loc[cardiac & (d["hr"] < 50) & (d["spo2"] < 90),
          "need_ventilator"] = 1

    # ── Trauma ───────────────────────────────────────────────────────────────
    trauma = d["emergency_type"] == "trauma"
    d.loc[trauma, "need_icu"]        = 1
    d.loc[trauma, "need_ot"]         = 1
    d.loc[trauma, "need_blood_bank"] = 1
    d.loc[trauma & (d["gcs"] < 9),  "need_neurosurgeon"] = 1
    d.loc[trauma & (d["gcs"] < 9),  "need_ct_scan"]      = 1
    d.loc[trauma & (d["shock_index"] > 1.0), "need_blood_bank"] = 1

    # ── Respiratory ──────────────────────────────────────────────────────────
    resp = d["emergency_type"] == "respiratory"
    d.loc[resp, "need_icu"]        = 1
    d.loc[resp & (d["spo2"] < 90), "need_ventilator"] = 1

    # ── Stroke / Neuro ───────────────────────────────────────────────────────
    neuro = d["emergency_type"] == "stroke_neuro"
    d.loc[neuro, "need_icu"]          = 1
    d.loc[neuro, "need_ct_scan"]      = 1
    d.loc[neuro, "need_neurosurgeon"] = 1

    # ── Sepsis ───────────────────────────────────────────────────────────────
    sepsis = d["emergency_type"] == "sepsis"
    d.loc[sepsis, "need_icu"] = 1
    d.loc[sepsis & (d["bp_sys"] < 90) & (d["hr"] > 100),
          "need_ventilator"] = 1

    # ── Poisoning / Overdose ─────────────────────────────────────────────────
    poison = d["emergency_type"] == "poisoning_overdose"
    d.loc[poison, "need_icu"]        = 1
    d.loc[poison, "need_toxicology"] = 1
    d.loc[poison & (d["gcs"] < 9),   "need_ventilator"] = 1

    # ── Obstetric ────────────────────────────────────────────────────────────
    obs = d["emergency_type"] == "obstetric"
    d.loc[obs, "need_ot"]           = 1
    d.loc[obs, "need_obstetrician"] = 1
    d.loc[obs, "need_blood_bank"]   = 1
    d.loc[obs & (d["shock_index"] > 1.0), "need_icu"] = 1

    # ── Diabetic ─────────────────────────────────────────────────────────────
    diab = d["emergency_type"] == "diabetic"
    d.loc[diab & (d["gcs"] < 10),   "need_icu"] = 1

    return d


def assign_severity(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    score = np.zeros(len(d))

    score += np.where(d["spo2"] < 90,  2, 0)
    score += np.where(d["spo2"] < 85,  1, 0)  # extra penalty
    score += np.where(d["bp_sys"] < 80, 2, 0)
    score += np.where(d["gcs"] < 9,    2, 0)
    score += np.where(d["hr"] > 130,   1, 0)
    score += np.where(d["hr"] < 50,    1, 0)
    score += np.where(d["rr"] > 30,    1, 0)
    score += np.where(d["shock_index"] > 1.0, 1, 0)

    d["severity"] = pd.cut(
        score, bins=[-1, 1, 3, 5, 100],
        labels=["low", "moderate", "high", "critical"]
    ).astype(str)

    return d


def add_noise(df: pd.DataFrame, missing_rate: float = 0.05) -> pd.DataFrame:
    """Inject realistic ambulance-field missingness."""
    d = df.copy()
    # ECG and glucose are often unavailable in the field
    for col, rate in [("ecg_abnormal", 0.30), ("glucose", 0.15),
                      ("pupils_unequal", 0.10)]:
        mask = np.random.rand(len(d)) < rate
        d.loc[mask, col] = np.nan

    # Random missingness on vitals
    for col in ["bp_sys", "bp_dia", "spo2", "rr"]:
        mask = np.random.rand(len(d)) < missing_rate
        d.loc[mask, col] = np.nan

    return d


def generate_dataset(n: int = 20_000,
                     path: str = "triage_dataset.parquet") -> pd.DataFrame:
    print(f"Generating {n} triage records...")
    df = build_records(n)
    df = assign_care_needs(df)
    df = assign_severity(df)
    df = add_noise(df)

    # encode emergency_type as integer label for modelling
    type_map = {t: i for i, t in enumerate(EMERGENCY_TYPES)}
    df["emergency_type_label"] = df["emergency_type"].map(type_map)

    df.to_parquet(path, index=False)
    print(f"Saved to {path}  shape={df.shape}")
    print(df["emergency_type"].value_counts())
    print(df["severity"].value_counts())
    return df


if __name__ == "__main__":
    df = generate_dataset(N)
